# Receipt Printer


### Environment:
  * java version: 1.7.0_201

### How to run:
  * Linux Environment: 
      1. Move to project directory.
      2. run build script by typing "./build.sh" in the terminal.
      3. run run script by typing "./run.sh [input.txt]" in the terminal.

  * IntelliJ IDE:
      1. Get full Intellij project from: github.com/msc007/ReceiptPrinter
      2. Import project to IntelliJ IDE
      3. Manually change input file name in Main.java.

### Authors:
   * Min Choi



