#!/bin/bash


if [ -z "$1" ]; then
   echo "Missing input file!"
   echo "Usage: ./run.sh arg1.txt"
   echo "Exiting..."
   exit 1
fi

if [ ${1: -4} != ".txt" ]; then
   echo "Invalid input file type!"
   echo "Input file must have .txt extension"
   echo "Exiting..."
   exit 1
fi

java Main $1


