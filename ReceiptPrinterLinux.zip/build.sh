#!/bin/bash

chmod 777 *

javac *.java

chmod 777 *

echo Compiled Successfully!
